/*-------------------------------Module-------------------------------*/
const EXPRESS = require('express')
const APP = EXPRESS();
const MIDDLEWARE = require('./middleware/index');
const COMPRESSION = require('compression');
const USER_LISTEN = require('./LISTEN/userListen');
const SUBJECT_LISTEN = require('./LISTEN/subjectListen');
const ASSIGN_LISTEN = require('./LISTEN/AssignmentListen');
APP.set('env', 'development');
// APP.set('env','production');
const port = 8000

/*-------------------------------Middle Ware-------------------------------*/
//test
APP.use((req, res, next) => {
    console.log('conneted');
    next();
})

//parse application/x-www-form-urlencoded
APP.use(EXPRESS.urlencoded({ extended: true }))

//parse application/json
APP.use(EXPRESS.json())

//reqTime
APP.use(MIDDLEWARE.reqTime)

//JWT
APP.use(MIDDLEWARE.jwt)

//setHeaders
APP.use(MIDDLEWARE.setHeaders)

//GZIP
APP.use(COMPRESSION())

//User listening
USER_LISTEN(APP);

//Subject listening
SUBJECT_LISTEN(APP);

//Assignment listening
ASSIGN_LISTEN(APP);

APP.listen(port, () => console.log(`Example APP listening on port ${port}!`))