module.exports = {
    host: '47.95.111.177',
    user: 'schedule',
    password: 'nt4dHnN34SxyLP8j',
    port: '3306',
    database: 'schedule',
    charset: 'utf8mb4'
}