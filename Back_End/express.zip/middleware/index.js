const jwt = require('./events/jwt')
const reqTime = require('./events/reqTime')
const setHeaders = require('./events/setHeaders')
module.exports = { jwt, reqTime, setHeaders }