//const dateFormat = require('dateformat');
const reqTime = (req, res, next) => {
    req.reqTime = Date.now();
    console.log('reqTime', new Date())
    next();
}
module.exports = reqTime