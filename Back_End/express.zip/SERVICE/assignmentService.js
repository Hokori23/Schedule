const ACTION = require('../ACTION/assignmentAction');
const USER_SERVICE = require('./userService');

//检查权限
const getPower = async(id) => {
    try {
        let queryUser = await USER_SERVICE.query(id);
        if (queryUser[0].data.power >= 1) {
            return true
        } else {
            return false
        }
    } catch (e) {
        throw e
    }
}

//添加作业
const add = async(user, assignment) => {
    let res = {};
    try {
        if (await getPower(user.id)) {
            await USER_SERVICE.active(user);
            await ACTION.add(assignment);
            res.errcode = 0;
            res.data = await ACTION.queryNameAndDeadLine(assignment);
            res.msg = '添加作业成功';
        }
    } catch (e) {
        res.errcode = 1;
        res.msg = e.message;
    }
    return res;
}

//删除作业
const remove = async(user, assignment) => {
    let res = {};
    try {
        await USER_SERVICE.active(user)
        if (await getPower(user.id)) {
            let mayAssignment = await ACTION.queryNameAndDeadLine(assignment);
            if (mayAssignment.length) {
                res.errcode = 0;
                res.data = await ACTION.remove(assignment);
                res.msg = '删除作业成功'
            } else {
                res.errcode = 1;
                res.msg = '无此日作业'
            }
        }
    } catch (e) {
        res.errcode = 1;
        res.msg = e.message;
    }
}

//编辑作业
const edit = async(id, assignment) => {
    let res = {};
    try {
        if (await getPower(id)) {
            let mayAssignment = await ACTION.queryAll(assignment.deadLine);
            if (mayAssignment.length) {
                res.errcode = 0;
                res.data = await ACTION.edit(assignment);
                res.msg = '编辑作业成功'
            } else {
                res.errcode = 2;
                res.msg = '无此日作业，是否添加作业'
            }
        }
    } catch (e) {
        res.errcode = 1;
        res.msg = '编辑作业失败'
    }
    return res;
}

//查询作业
const query = async(id, name) => {
    let res = {};
    try {
        res.errcode = 0;
        res.data = await ACTION.query(name);
        res.msg = '查询作业成功'
    } catch (e) {
        res.errcode = 1;
        res.msg = '查询作业失败'
    }
    return res;
}

//遍历作业
const queryAll = async() => {
    let res = {};
    try {
        res.errcode = 0;
        res.data = await ACTION.queryAll();
        res.msg = '遍历作业成功'
    } catch (e) {
        res.errcode = 1;
        res.msg = '遍历作业失败'
    }
    return res;
}

module.exports = { add, remove, edit, query, queryAll }